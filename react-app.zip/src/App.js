import './App.css';
import { useEffect, useState } from 'react';
import { Container, FormControl, Row, Card } from 'react-bootstrap'
import { Input, Carousel, Button } from 'antd'


function App() {

  const [searchInput, setSearchInput] = useState("");
  const [accessToken, setToken] = useState("");
  const [albums, setAlbums] = useState([]);

  useEffect(() => {
    var authParam = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: 'grant_type=client_credentials&client_id=b5486f3cf799494fb48e8e7228b9867b&client_secret=9832aa914418470abe7f69a18888ee95'
    }
    fetch('https://accounts.spotify.com/api/token', authParam)
      .then(result => result.json())
      .then(data => setToken(data.access_token));
  }, []);

  async function search() {
    console.log("search for " + searchInput)

    var searchparam = {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + accessToken
      }
    }

    var artistId = await fetch('https://api.spotify.com/v1/search?q=' + searchInput + '&type=artist', searchparam)
      .then(response => response.json())
      .then(data => { return data.artists.items[0].id })

    var albums = await fetch('https://api.spotify.com/v1/artists/' + artistId + '/albums' + '?include_groups=album&market=US&limit=50', searchparam)
      .then(response => response.json())
      .then(data => setAlbums(data.items))

  }

  console.log(albums)

  const contentStyle = {
    height: '160px',
    color: '#fff',
    lineHeight: '160px',
    textAlign: 'center',
    background: '#364d79',
  };

  return (
    <div className="">
      <Container>
        <Input
          placeholder='hello'
          onChange={event => setSearchInput(event.target.value)}
          onKeyPress={event => {
            if (event.key == "Enter") { search() }
          }}
        />
        <Button className="bg-[#292929] text-[#81b71a] font-bold snap-center" onClick={search}>Search</Button>
      </Container>
      <Carousel autoplay >
        {albums.map(album => {
          return (
            <div>
              <img src={album.images[0].url} style={contentStyle} />
              <h3 style={contentStyle}>{album.name}</h3>
            </div>
          )
        })}
      </Carousel>
    </div >
  );
}

export default App;
